#include "liststatis.h"

/**** Konstruktor List Kosong ****/
void CreateList(List *L){
    First(*L) = Nil;

    /* inisialisasi semua elemen array */
    for(int i=0;i<MaxEl;i++){
        L->A[i].next = Nil;
    }
}

/**** Manajemen Elemen (Alokasi dari array kosong) ****/
address Alokasi(List *L, infotype X){
    address P = Nil;

    for(int i=0;i<MaxEl;i++){
        if(L->A[i].next == Nil && i != First(*L)){
            P = i;
            L->A[i].info = X;
            L->A[i].next = Nil;
            break;
        }
    }

    return P;
}

void DeAlokasi(List *L, address P){
    L->A[P].next = Nil;
}

/**** Search ****/
address Search(List L, infotype X){
    address P = First(L);

    while(P != Nil){
        if(L.A[P].info == X){
            return P;
        }
        P = L.A[P].next;
    }

    return Nil;
}

/**** INSERT BERDASARKAN NILAI ****/

void InsVFirst(List *L, infotype X){
    address P = Alokasi(L,X);

    if(P != Nil){
        InsertFirst(L,P);
    }
}

/**** DELETE BERDASARKAN NILAI ****/

void DelVFirst(List *L, infotype *X){
    address P;

    DelFirst(L,&P);
    *X = L->A[P].info;
    DeAlokasi(L,P);
}

/**** INSERT BERDASARKAN ADDRESS ****/

void InsertFirst(List *L, address P){
    L->A[P].next = First(*L);
    First(*L) = P;
}

/**** DELETE BERDASARKAN ADDRESS ****/

void DelFirst(List *L, address *P){
    *P = First(*L);

    First(*L) = L->A[*P].next;
}